<!-- FOOTER START -->
<section class="footer-section bg-green" style="border-top: 1px solid #fff;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12 text-center">
                <div class="footer-menu ab-sm-15">
                    <ul class="list-unstyled social-icon mb-0">
                        <li class="list-inline-item"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-dribbble"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                    </ul>
                    <p class="pt-4 pb-2"> &copy; 2010 - 2020 INISTORY ALL RIGHT RESERVED </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- FOOTER END -->
<!-- Back to top -->    
<!-- <a href="#" class="back-to-top" id="back-to-top"> 
    <i class="mdi mdi-chevron-up"> </i> 
</a> -->
<!-- Back to top --> 
