<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Home Page Contents
    |--------------------------------------------------------------------------
    */

    'home' => 'Home',
    'about' => 'About',
    'investmentSectors' => 'Investment Sectors',
    'network' => 'Network',
    'blog' => 'Blog',
    'english' => 'English',
    'arabic' => 'Arabic',
    /************* Home **************/
    'investmentCompany' => 'Investment Company',
    'aboutUs' => 'About Us',
    'ourNetwork' => 'Our Network',
    'blog' => 'Blog',
    'more' => 'More',
    'successStories' => 'Success Stories',
    'contactUs' => 'Contact Us',
    /*** Contact Form ***/
    'fullName' => 'Full Name',
    'email' => 'EMail',
    'message' => 'Message',
    'sendMessage' => 'Send Message',

    /*
    |--------------------------------------------------------------------------
    | Sectors Page Contents
    |--------------------------------------------------------------------------
    */

    
    
];
