
<!-- Navigation Bar-->
<nav class="navbar navbar-expand-md fixed-top navbar-custom sticky sticky-dark bg-white">
    <div class="container row mx-0 d-flex justify-content-center">
        
            <!-- LOGO -->
            <a class="navbar-brand logo text-green" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/Investin-logo.png')); ?>" alt="missing_logo" height="40">
                <!-- Invesin -->
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>    
        
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav navbar-center px-auto text-center" id="mySidenav">
                
                    <li class="nav-item current">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link px-0 text-uppercase"><?php echo e(__('content.home')); ?></a>
                    </li>
                    <?php if(Route::CurrentRouteName() == 'home' ): ?>
                        <li class="nav-item"> 
                            <a href="#about" class="nav-link px-0 text-uppercase"><?php echo e(__('content.about')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link px-0 text-uppercase"><?php echo e(__('content.investmentSectors')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="#network" class="nav-link px-0 text-uppercase"><?php echo e(__('content.network')); ?></a>
                        </li>    
                    <?php endif; ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('blog')); ?>" class="nav-link px-0 text-uppercase"><?php echo e(__('content.blog')); ?></a>
                    </li>
                    
                    <li class="nav-item">
                        <span class="nav-link px-0">
                            <?php if(App::getLocale() == 'en'): ?>
                            <img src="<?php echo e(asset('images/sudan.svg')); ?>" class="lang-svg" alt=""> <a href="<?php echo e(url('locale/ar')); ?>" class="mx-1"><?php echo e(__('content.arabic')); ?></a> 
    
                                
    
                            <?php else: ?>
                            <a href="<?php echo e(url('locale/en')); ?>" class=""><img src="<?php echo e(asset('images/united-kingdom.svg')); ?>" class="lang-svg mx-1" alt=""> <?php echo e(__('content.english')); ?></a>
                            <?php endif; ?>
                        </span>
                    </li>
                       
                
            </ul>
            
        </div>
    </div>
</nav>




        <?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/partials/navbar.blade.php ENDPATH**/ ?>