

<?php $__env->startSection('content'); ?>
         
<section class="section bg-grey">

    <div class="row justify-content-center  mt-5">
        <div class="col-lg-4 col-sm-10">
            <form action="<?php echo e(route('shares_order', $id)); ?>" method="POST" class="bg-green custom-form p-5">
                <?php echo csrf_field(); ?>
                <div class="input-data">
                    <input type="text" class="" name="name" required>
                    <div class="underline"></div>
                    <label for=""><?php echo e(__('content.fullName')); ?></label>
                </div>
                <div class="input-data">
                    <input type="text" class="" name="phone_number" required>
                    <div class="underline"></div>
                    <label for=""><?php echo e(__('content.phoneNumber')); ?></label>
                </div>
                <div class="input-data">
                    <input type="text" class="" name="address" required>
                    <div class="underline"></div>
                    <label for=""><?php echo e(__('content.address')); ?></label>
                </div>
                <div class="input-data">
                    <input type="email" class="" name="email" required>
                    <div class="underline"></div>
                    <label for=""><?php echo e(__('content.email')); ?></label>
                </div>
                <div class="input-data">
                    <input type="number" name="num_of_taken_share" id="" class="" required>
                    <div class="underline"></div>
                    <label for="" class="text-capitalize"><?php echo e(__('content.numberOfShares')); ?></label>

                </div>
                <input type="text" hidden name="session_id" value="<?php echo e($id); ?>">
                <button type="submit" class="btn btn-contact text-uppercase py-2"> <?php echo e(__('content.order')); ?></button>

            </form>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/pages/order.blade.php ENDPATH**/ ?>