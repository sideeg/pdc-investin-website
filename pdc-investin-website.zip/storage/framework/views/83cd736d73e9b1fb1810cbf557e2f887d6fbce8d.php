

<?php $__env->startSection('content'); ?>
         
<section class="section bg-grey">

    <div class="row justify-content-center  mt-5">
        <div class="col-lg-4 col-sm-10">
            <form action="#" class="bg-green custom-form p-5">
                <div class="input-data">
                    <input type="text" class="" required>
                    <div class="underline"></div>
                    <label for="">full name</label>
                </div>
                <div class="input-data">
                    <input type="text" class="" required>
                    <div class="underline"></div>
                    <label for="">full name</label>
                </div>
                <div class="input-data">
                    <input type="text" class="" required>
                    <div class="underline"></div>
                    <label for="">full name</label>
                </div>
                <div class="input-data">
                    <input type="email" class="" required>
                    <div class="underline"></div>
                    <label for="">full name</label>
                </div>
                <div class="input-data">
                    
                    <input type="number" name="" id="" class="" required>
                    <div class="underline"></div>
                    <label for="" class="text-capitalize">Number of Shares</label>

                </div>
                <button type="submit" class="btn btn-contact text-uppercase py-2"> Order</button>

            </form>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/pages/order.blade.php ENDPATH**/ ?>