

<?php $__env->startSection('content'); ?>


<!-- BLOG -->
<section class="section bg-grey">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title-heading">
                    <h2 class="color-green text-center dot"><?php echo e(__('content.blog')); ?></h2>
                    <div class="row justify-content-center">
                    <p class="mx-auto my-3 col-lg-6 col-md-6 col-sm-12 text-center">
                        <?php if(App::getLocale() == 'en'): ?>
                            <?php echo e($blog->first()->intro_en); ?>

                        <?php else: ?>
                            <?php echo e($blog->first()->intro_ar); ?>

                        <?php endif; ?>
                    </p>

                    </div>

                    
                    <?php if(App::getLocale() == 'en'): ?>
                        <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="row mx-0 justify-content-center">
                                <div class="col-lg-10 col-md-7 col-sm-12 col-xs-12 my-3">
                                    <div class="row mx-0 article">
                                        <div class="col-lg-4 blog-img px-0">
                                            <img src="<?php echo e(asset($item->image_full_path)); ?>" class="img-responsive img-blog-side " alt="">
                                            <div class="blog-overlay"></div>
                                            
                                        </div>
                                        <div class="blog-text col-lg-6">
                                            <h4 class="my-3 text-black word-keep">
                                                <?php echo e($item->blog_name_en); ?>

                                            </h4>
                                            <p class="">
                                                <?php echo e($item->Brief_en); ?>

                                            </p>
                                            <a href="<?php echo e(route('article', $item->id)); ?>" class="btn-blog"><?php echo e(__('content.readFull')); ?></a>
                                        </div>
                                        <div class="col-lg-2">
                                            <h5 class="my-3 text-green2 text-center blog-date"> <span class="d-block day"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('H')); ?></span> <span  class="d-block month">Novmber</span> <span class="d-block year">2020</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    <?php else: ?>
                        <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="row mx-0 justify-content-center">
                                <div class="col-lg-10 col-md-7 col-sm-12 col-xs-12 my-3">
                                    <div class="row mx-0 article">
                                        <div class="col-lg-4 blog-img px-0">
                                            <img src="<?php echo e(asset($item->image_full_path)); ?>" class="img-responsive img-blog-side " alt="">
                                            <div class="blog-overlay"></div>
                                            
                                        </div>
                                        <div class="blog-text col-lg-6">
                                            <h4 class="my-3 text-black word-keep">
                                                <?php echo e($item->blog_name_en); ?>

                                            </h4>
                                            <p class="">
                                                <?php echo e($item->Brief_en); ?>

                                            </p>
                                            <a href="<?php echo e(route('article', $item->id)); ?>" class="btn-blog"><?php echo e(__('content.readFull')); ?></a>
                                        </div>
                                        <div class="col-lg-2">
                                            <h5 class="my-3 text-green2 text-center blog-date"> <span class="d-block day"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('H')); ?></span> <span  class="d-block month"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('F')); ?></span> <span class="d-block year"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('yy')); ?></span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    <?php endif; ?>

                    

                    
                </div>
                <div class="row justify-content-center my-3">
                    <?php echo e($blog->links()); ?>    
                </div>
            </div>
        </div>
    </div>
</section>
<!-- BLOG END -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/pages/blog.blade.php ENDPATH**/ ?>