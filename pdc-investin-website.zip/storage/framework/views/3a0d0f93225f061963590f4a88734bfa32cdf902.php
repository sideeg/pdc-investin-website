<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    


<?php echo $__env->make('partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
</head>

    <body>
        
    
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main id="main" class="" style="width:100%; margin:0;padding:0;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>


    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/layouts/main.blade.php ENDPATH**/ ?>