
        <!-- js placed at the end of the document so the pages load faster -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/scrollspy.min.js')); ?>"></script>
        <!-- easing -->
        <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.easypiechart.min.js')); ?>"></script>

        <!-- Read More -->
        <script src="<?php echo e(asset('js/jquery.show-more.js')); ?>"></script>
        <!-- Portfolio -->
        <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/isotope.js')); ?>"></script>
        <script src="<?php echo e(asset('js/portfolio-filter.js')); ?>"></script> 
        <!-- Carousel -->
        <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/owlcarousel.init.js')); ?>"></script>
        <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script> 
        <script src="<?php echo e(asset('js/slick.init.js')); ?>"></script> 
        <!-- VIDEO ICON -->
        <script src="<?php echo e(asset('js/magnific.init.js')); ?>"></script>
        <!-- COUNTER -->
        <script src="<?php echo e(asset('js/counter.init.js')); ?>"></script>
        <!-- CONTACT -->
        <script src="<?php echo e(asset('js/contact.js')); ?>"></script>
        <!--custom script-->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        
        <script>
            

            $(document).ready(function() {
                var readMore = document.getElementById('readMore').innerText;
                var readLess = document.getElementById('readLess').innerText;
                $('#history').showMore({
                    minheight: 200,
                    buttontxtmore: readMore,
                    buttontxtless: readLess,
                    buttoncss: 'my-3 showmore-button',
                    animationspeed: 550
                });
            });

            $('.chart').easyPieChart();

        </script><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/partials/scripts.blade.php ENDPATH**/ ?>