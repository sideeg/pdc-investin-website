

<?php $__env->startSection('content'); ?>



<section class="section">

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <article class="post mx-0">
                <div class="post-preview">
                    <img src="<?php echo e(asset($blog[0]->image_full_path)); ?>" alt="" class="img-fluid mx-auto d-block">
                </div>

                <div class="post-header mb-0">
                    <ul class="post-meta">
                        <li class="row">
                            <p class="text-muted text-small text-left mx-4 pb-4 row"><i class="mdi mdi-calendar text-black mx-1"></i> <span class=""> <?php echo e(\Carbon\Carbon::parse($blog[0]->created_at)->format('d M ,yy')); ?></span></p>
                            
                            
                        
                        </li>
                        <!-- <li><i class="mdi mdi-tag-text-outline"></i> -->
                            <!-- <a href="#"> <small>Photography</small></a></li> -->
                    </ul>
                    
                    <div class="post-content">
                        <h4>
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo e($blog->first()->blog_name_en); ?>

                            <?php else: ?>
                                <?php echo e($blog->first()->blog_name_ar); ?>

                            <?php endif; ?>
                        </h4>
                        <p class="mb-0">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo e($blog->first()->text_en); ?>

                            <?php else: ?>
                                <?php echo e($blog->first()->text_ar); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </article>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/pages/article.blade.php ENDPATH**/ ?>