

<?php $__env->startSection('content'); ?>


    <!-- HOME START-->
    <section id="home" class="bg-half" style="background-image: url('<?php echo e(asset($intro[0]->icon_full_path)); ?>');object-fit: contain;" id="home">
        <div class="bg-overlay"></div>
        <div class="home-center">
            <div class="home-desc-center">
                <div class="container title-perticle">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                            <div class="title-heading text-center">
                                <img src="images/Investin-logo.png" class="mb-2 home-logo" alt="missing_logo">
                                <!-- <h1 class="text-green">INVESTIN</h1> -->
                                <?php if(App::getLocale() == 'en'): ?>

                                <h2 class="text-black text-uppercase word-keep">
                                    <?php echo e($intro[0]->section_name_en); ?>

                                </h2>
                                <div class="row justify-content-center">
                                <p class="text-black landing-3 col-lg-6 col-md-6 col-sm-12">
                                        <?php echo e($intro[0]->intro_en); ?>

                                </p>
                                <?php else: ?>

                                <h2 class="text-black text-uppercase word-keep">
                                    <?php echo e($intro[0]->section_name_ar); ?>

                                </h2>
                                <div class="row justify-content-center">
                                <p class="text-black landing-3 col-lg-6 col-md-6 col-sm-12">
                                    <?php echo e($intro[0]->intro_ar); ?>

                                </p>
                                <?php endif; ?>
                                
                                </div>
                                <!-- <div class="text-center subcribe-form mt-5">
                                    <form action="#">
                                        <input type="text" name="email" placeholder="E-mail">
                                        <button type="submit" class="btn btn-custom">Subcribe</button>
                                    </form>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- HOME END--> 

    <!-- ABOUT US -->
    <section id="about-us" class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-heading">
                        <h2 class="color-green text-center word-keep dot"><?php echo e(__('content.aboutUs')); ?></h2>
                        <div class="row justify-content-center">
                        <p class="mx-auto my-3 text-center col-lg-6 col-md-6 col-sm-12">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo e($about_us->first()->intro_en); ?>

                            <?php else: ?>
                                <?php echo e($about_us->first()->intro_ar); ?>

                            <?php endif; ?>
                        </p>

                        </div>
                        <div class="row justify-content-center">
                            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12">
                                <div id="history" class="row">
                                    <div class="row time-line-row mx-2">
                                        <div class="col-12 row m-0 time-line">
                                            <div class="col-12 text-green font-b">2014</div>
                                            <div class="col-12 mb-5">Establishment of the company</div>
                                        </div>
                                        <?php if(App::getLocale() == 'en'): ?>
                                            <?php $__currentLoopData = $about_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-12 row m-0 time-line">
                                                <div class="col-12 text-green font-b"><?php echo e($item->date); ?></div>
                                                    <div class="col-12 mb-5"><?php echo e($item->action_en); ?></div>
                                                </div>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $about_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-12 row m-0 time-line">
                                                <div class="col-12 text-green font-b"><?php echo e($item->date); ?></div>
                                                    <div class="col-12 mb-5"><?php echo e($item->action_ar); ?></div>
                                                </div>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12">
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php echo e($about_us->first()->text_en); ?>

                                <?php else: ?>
                                    <?php echo e($about_us->first()->text_ar); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div hidden>
        <span id="readMore"><?php echo e(__('content.readMore')); ?></span>
        <span id="readLess"><?php echo e(__('content.readLess')); ?></span>
    </div>
    <!-- ABOUT US END -->
    
    <!-- SECTORS -->
    <section id="sectors" class="section bg-green">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-heading">
                        <h2 class="text-uppercase text-center text-white word-keep dot-white"><?php echo e(__('content.investmentSectors')); ?></h2>
                        <div class="row justify-content-center">
                        <p class="mx-auto my-4 text-center text-white col-lg-6 col-md-6 col-sm-12">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo e($sector[0]->intro_en); ?>        
                            <?php else: ?>
                                <?php echo e($sector[0]->intro_ar); ?>    
                            <?php endif; ?>
                        </p>

                        </div>
                        <div class="container">
                            <div class="row justify-content-center">
                                

                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php $__currentLoopData = $sector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <div class="feature">
                                                <a href="<?php echo e(route('sector', $item->id)); ?>" class="link-sector">

                                                    <div class="fe-icon row ">
                                                        <!-- <i class="fas fa-seedling"></i> -->
                                                        <img src="<?php echo e(asset($item->icon_full_path)); ?>" alt="" srcset="">
                                                        <h3 class="word-keep"><?php echo e($item->sector_name_en); ?></h3>
                                                    </div>
                                                </a>
                                                <div class="fe-head">
                                                    <p>
                                                        <?php echo e($item->Brief_en); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $sector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <div class="feature">
                                                <a href="<?php echo e(route('sector', $item->id)); ?>" class="link-sector">
                                                    <div class="fe-icon row ">
                                                        <!-- <i class="fas fa-seedling"></i> -->
                                                        <img src="<?php echo e(asset($item->icon_full_path)); ?>" alt="" srcset="">
                                                        <h3 class="word-keep"><?php echo e($item->sector_name_ar); ?></h3>
                                                    </div>
                                                </a>
                                                <div class="fe-head">
                                                    <p>
                                                        <?php echo e($item->Brief_ar); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- SECTORS END -->
    
    <!-- OUR NETWORK -->
    <section id="our-network" class="section bg-grey">
        <div class="container">
            <div class="title-heading text-center">
                <h2 class="text-uppercase word-keep dot"><?php echo e(__('content.ourNetwork')); ?></h2>
                <div class="row justify-content-center">
                    <p class="mx-auto my-4 text-center col-lg-6 col-md-6 col-sm-12">
                        <?php if(App::getLocale() == 'en'): ?>
                            <?php echo e($our_network[0]->intro_en); ?>        
                        <?php else: ?>
                            <?php echo e($our_network[0]->intro_ar); ?>    
                        <?php endif; ?>
                    </p>
                </div>
                <div class="container">
               
                    <div class="row justify-content-center">
                        <?php $__empty_1 = true; $__currentLoopData = $our_network; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4 col-sm-6">
                            <div class="network">
                                <img src="<?php echo e(asset($item->logo_full_path)); ?>" class="img-responsive img-network" alt="" srcset="">
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                        <?php endif; ?>
                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- OUR NETWORK END -->

    <!-- BLOG -->
    <section class="section bg-green">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-heading text-center">
                        <h2 class="text-uppercase text-white word-keep dot-white"><?php echo e(__('content.blog')); ?></h2>
                        <div class="row justify-content-center">
                            <p class="mx-auto my-4 text-center text-white col-lg-6 col-md-6 col-sm-12">
                            
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php echo e($blog->first()->intro_en); ?>        
                                <?php else: ?>
                                    <?php echo e($blog->first()->intro_ar); ?>    
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="container">
                            <div class="row blog align-items-start">
                                
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                            <div class="post-articles">
                                                <div class="first-section">
                                                    <img src="<?php echo e(asset($item->image_full_path)); ?>" class="img-responsive img-blog-top" alt="" srcset="">
                                                    <div class="first-section-overlay"></div>
                                                    <h4 class="blog-title word-keep"><a href="<?php echo e(route('article', $item->id)); ?>" class="text-white"><?php echo e($item->blog_name_en); ?></a></h4>
                                                </div>
                                                <div class="second-section">
                                                    <p class="text-left mx-4 mt-2">
                                                        <?php echo e($item->Brief_en); ?>

                                                    </p>
                                                <p class="text-muted text-small text-left mx-4 pb-4 row"><i class="mdi mdi-calendar text-black mx-1"></i> <span class=""> <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d M, yy')); ?></span></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                                <?php else: ?>
                                    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                            <div class="post-articles">
                                                <div class="first-section">
                                                    <img src="images/about/about-page.jpg" class="img-responsive img-blog-top" alt="" srcset="">
                                                    <div class="first-section-overlay"></div>
                                                    <h4 class="blog-title word-keep"><a href="<?php echo e(route('article', $item->id)); ?>" class="text-white"><?php echo e($item->blog_name_ar); ?></a></h4>
                                                </div>
                                                <div class="second-section">
                                                    <p class="text-left mx-4 mt-2">
                                                        <?php echo e($item->Brief_ar); ?>

                                                    </p>
                                                <p class="text-muted text-small text-left mx-4 pb-4 row"><i class="mdi mdi-calendar text-black mx-1"></i> <span class=""> <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('yy, M d')); ?></span></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <h4 class="text-center mt-5 more-arrow"><a href="<?php echo e(route('blog')); ?>" class="text-white"><?php echo e(__('content.more')); ?></a></h4>
        </div>
    </section>
    <!-- BLOG END -->
    
    <!-- SUCCESS -->
    <section id="success-stories" class="section bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-heading">
                        <h2 class="text-uppercase text-center text-green dot"><?php echo e(__('content.successStories')); ?></h2>
                        <p class="mx-auto my-5 text-muted text-center">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo e($success_stories->first()->intro_en); ?>

                            <?php else: ?>
                                <?php echo e($success_stories->first()->intro_ar); ?>

                            <?php endif; ?>
                        </p>
                        <div class="container">
                            <div class="row justify-content-center">
                                <div id="owl-success-stories" class="owl-crousel">
                                    
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $success_stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="col-lg-4 col-md-6 col-sm-12 bg-white m-2 success-story item">
                                                <div class="row w-100">
                                                    <div class="col-3">
                                                        <!-- <a href="https://fontawesome.com/icons?d=gallery&q=arrow&m=free" target="_blank"> -->
                                                        <img src="<?php echo e(asset($item->icon_full_path)); ?>" class="success-avatar my-2" alt="" srcset="">
                                                        <!-- </a> -->
                                                    </div>
                                                    <div class="col-9 success-name">
                                                        <h5 class="my-2"><?php echo e($item->name_en); ?></h5>
                                                        <span><?php echo e($item->created_at->diffForHumans()); ?></span>
                                                    </div>
                                                </div>
                                                <p>
                                                    <?php echo e($item->text_en); ?>    
                                                </p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $success_stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="col-lg-4 col-md-6 col-sm-12 bg-white m-2 success-story item">
                                                <div class="row w-100">
                                                    <div class="col-3">
                                                        <!-- <a href="https://fontawesome.com/icons?d=gallery&q=arrow&m=free" target="_blank"> -->
                                                        <img src="<?php echo e(asset($item->icon_full_path)); ?>" class="success-avatar my-2" alt="" srcset="">
                                                        <!-- </a> -->
                                                    </div>
                                                    <div class="col-9 success-name">
                                                        <h5 class="my-2"><?php echo e($item->name_ar); ?></h5>
                                                        <span><?php echo e($item->created_at->diffForHumans()); ?></span>
                                                    </div>
                                                </div>
                                                <p>
                                                    <?php echo e($item->text_ar); ?>    
                                                </p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <div class="col-lg-4 col-md-6 col-sm-12 bg-white m-2 success-story item">
                                        <div class="row w-100">
                                            <div class="col-3">
                                            <img src="images/about/about-page.jpg" class="success-avatar my-2" alt="" srcset="">
                                            </div>
                                            <div class="col-9">
                                                <h5 class="my-2">mohammed saeed</h5>
                                                <span>3 Days Later</span>
                                            </div>
                                        </div>
                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic autem ratione laborum modi, obcaecati saepe dolorum aliquid? Magni, nulla minus!</p>
                                    </div>

                                    <div class="col-lg-4 col-md-6 col-sm-12 bg-white m-2 success-story item">
                                        <div class="row w-100">
                                            <div class="col-3">
                                            <img src="images/about/about-page.jpg" class="success-avatar my-2" alt="" srcset="">
                                            </div>
                                            <div class="col-9">
                                                <h5 class="my-2">mohammed saeed</h5>
                                                <span>3 Days Later</span>
                                            </div>
                                        </div>
                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic autem ratione laborum modi, obcaecati saepe dolorum aliquid? Magni, nulla minus!</p>
                                    </div>

                                    <div class="col-lg-4 col-md-6 col-sm-12 bg-white m-2 success-story item">
                                        <div class="row w-100">
                                            <div class="col-3">
                                            <img src="images/about/about-page.jpg" class="success-avatar my-2" alt="" srcset="">
                                            </div>
                                            <div class="col-9">
                                                <h5 class="my-2">mohammed saeed</h5>
                                                <span>3 Days Later</span>
                                            </div>
                                        </div>
                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic autem ratione laborum modi, obcaecati saepe dolorum aliquid? Magni, nulla minus!</p>
                                    </div>
                                    
                                </div>
                                
                                <!-- <div class="col-lg-4 col-md-6 col-sm-12">

                                    <div id="testi-two" class="owl-carousel">
                                        <div class="testi-box">
                                            <div class="bg-white m-2 success-story">
                                                <div class="row">
                                                    <div class="col-3">
                                                    <img src="images/about/about-page.jpg" class="success-avatar m-2" alt="" srcset="">
                                                    </div>
                                                    <div class="col-9">
                                                        <h4>mohammed saeed</h4>
                                                        <span>3 Days Later</span>
                                                    </div>
                                                </div>
                                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic autem ratione laborum modi, obcaecati saepe dolorum aliquid? Magni, nulla minus!</p>
                                            </div>
                                        </div>
                                        <div class="testi-box">
                                            <div class="bg-white m-2 success-story">
                                                <div class="row">
                                                    <div class="col-3">
                                                    <img src="images/about/about-page.jpg" class="success-avatar m-2" alt="" srcset="">
                                                    </div>
                                                    <div class="col-9">
                                                        <h4>mohammed saeed</h4>
                                                        <span>3 Days Later</span>
                                                    </div>
                                                </div>
                                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic autem ratione laborum modi, obcaecati saepe dolorum aliquid? Magni, nulla minus!</p>
                                            </div>
                                        </div>
                                        <div class="testi-box">
                                            <div class="bg-white m-2 success-story">
                                                <div class="row">
                                                    <div class="col-3">
                                                    <img src="images/about/about-page.jpg" class="success-avatar m-2" alt="" srcset="">
                                                    </div>
                                                    <div class="col-9">
                                                        <h4>mohammed saeed</h4>
                                                        <span>3 Days Later</span>
                                                    </div>
                                                </div>
                                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic autem ratione laborum modi, obcaecati saepe dolorum aliquid? Magni, nulla minus!</p>
                                            </div>
                                        </div>
                                    </div>

                                </div> -->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- SUCCESS END -->

    <!-- CONTACT US -->
    <section class="section bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-heading">
                        <h2 class="text-uppercase text-center text-green word-keep dot"><?php echo e(__('content.contactUs')); ?></h2>

                        <div class="container mt-5">
                            <div class="row justify-content-space">
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <form action="<?php echo e(route('contact')); ?>" method="POST" class="p-4 bg-green custom-form">
                                        <?php echo csrf_field(); ?>
                                        <div class="">
                                            <div class="input-data">
                                                <input type="text" name="name" required >
                                                <div class="underline"></div>
                                                <label for=""><?php echo e(__('content.fullName')); ?></label>
                                            </div>
                                            <div class="input-data">
                                                <input type="text" name="email" required>
                                                <div class="underline"></div>
                                                <label for=""><?php echo e(__('content.email')); ?></label>
                                            </div>
                                            <div class="input-data">
                                                <input type="text" name="subject" required>
                                                <div class="underline"></div>
                                                <label for=""><?php echo e(__('content.subject')); ?></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="message" class="text-white"><?php echo e(__('content.message')); ?></label>
                                                <textarea name="message" id="message" class="form-control" cols="30" rows="10"></textarea>

                                            </div>

                                            <button type="submit" class="btn btn-contact text-uppercase py-2"> <?php echo e(__('content.sendMessage')); ?></button>

                                        </div>
                                    </form>
                                
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-12 my-2">
                                    <div class="map video-app-box mt-30">
                                        <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d6030.418742494061!2d-111.34563870463673!3d26.01036670629853!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2smx!4v1471908546569" style="border: 1px solid #fff;width:100%;height:20rem" allowfullscreen></iframe>
                                    </div>
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem ea corporis aut explicabo fugit aperiam qui commodi, atque tempore dolorem molestiae, necessitatibus perferendis totam? Architecto molestiae, impedit vel nam recusandae distinctio illo. Culpa cupiditate dolor eaque nemo, neque quas explicabo!
                                </div>
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="contact-info">
                                        <div class="contact-row row"><span class="icon col-lg-3 col-sm-12"><i class="fas fa-at m-3"></i></span><span class="info-text col-lg-9 col-sm-12">INVOICE@GMAIL.COM</span></div>
                                        <div class="contact-row row"><span class="icon col-lg-3 col-sm-12"><i class="fas fa-at m-3"></i></span><span class="info-text col-lg-9 col-sm-12">+123456789</span></div>
                                        <div class="contact-row row"><span class="icon col-lg-3 col-sm-12"><i class="fas fa-map-marker-alt m-3"></i></span><span class="info-text col-lg-9 col-sm-12">SUDAN, KHARTOUM KH STREET BUILDING 22</span></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTACT US END -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\InviestIn\pdc-investin-website\resources\views/index.blade.php ENDPATH**/ ?>