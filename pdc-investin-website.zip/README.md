you have to use "composer require doctrine/dbal" before migrate
