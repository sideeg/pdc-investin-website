you have to use "composer require doctrine/dbal" bbefore migrate
